export const BASE_URL = "https://rickandmortyapi.com/api/character/";
export const BASE_URL_2 = "test";

const URL_3 = "blah";

export default URL_3;
