import React from "react";
import List from "../characters/List";

function Home() {
    return <List />;
}

export default Home;
